//"use strict"

const body = document.body;
let block = document.querySelector(".div__span")
let iconFont = document.querySelector(".iconfont")
let bodyWidth = body.clientWidth/2;



console.log(bodyWidth);
 
iconFontWidth = iconFont.clientWidth;


block.addEventListener("mousedown", function(e){
    block.addEventListener("mousemove", mouseDrag);

    
})

function mouseDrag(event){
    const x = event.pageX;
    const y = event.pageY;
    console.log(x,y)

    
    
    block.style.display = "block";
    iconFont.style.position = "sticky";
    iconFont.style.left = x + "px";
    iconFont.style.top = y + "px";

    
}

block.addEventListener("mouseup", function(e){
    block.removeEventListener("mousemove", mouseDrag);

    
})


